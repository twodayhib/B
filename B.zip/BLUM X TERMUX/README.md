# BLUM Bot
BLUM Bot 

Register Here : [BLUM Bot](https://t.me/blum/app?startapp=ref_cP3J9CZ8o0)

Join to My Telegram Group : [Droppers](https://t.me/droppers_info)


## Tutorial

Install with python


## Features
- Auto Claim Bot
- Auto Clear Task

